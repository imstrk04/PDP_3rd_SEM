class Convert:

    def Convert_hrs_days(eslf, hours):
        return hours/24

    def Convert_days_hours(self, days):
        return days*24

    def Convert_man_hrs_days(self, hours):
        return hours/8