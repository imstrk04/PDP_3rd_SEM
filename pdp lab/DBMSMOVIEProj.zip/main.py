from MovieBookingSystem import login

if __name__ == '__main__':
  login.main()
