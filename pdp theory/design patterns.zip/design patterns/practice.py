'''class Person:

    def __init__(self, name, category, department = None, salary = 0):
        self.name = name
        self.category = category
        self.department = department
        self.salary = salary

class Iterable:

    def create_iterator(self):
        pass

class Iterator:

    def has_next():
        pass

    def next():
        pass

class List(Iterable):

    def __init__(self):
        self.list = []
    
    def create_iterator(self):
        return ListIterator(self)
    
    def attach(self, item):
        self.list.append(item)

class ListIterator(Iterator):

    def __init__(self, iterable):
        self.iterable = iterable
        self.index = 0
    
    def has_next(self):
        return self.index < len(self.iterable.list)
    
    def next(self):
        if self.has_next():
            value = self.iterable.list[self.index]
            self.index += 1
            return value
        else:
            raise StopIteration("No more elements")
        
if __name__ == '__main__':
    PplAsn = List()
    n = int(input("Enter number of inputs: "))
    for i in range(n):
        name = input("Enter Name: ")
        category = input("Student/ Faculty: ")
        department = input("Department: ")
        person = Person(name, category, department)
        PplAsn.attach(person)
    
    category_choice = input("Enter category of your choice: ")
    iterator = PplAsn.create_iterator()

    while iterator.has_next():
        person = iterator.next()
        if person.category.lower() == category_choice.lower():
            # Add New Year bonus of Rs 2000 to the salary of security personnel
            if person.department.lower() == category_choice.lower():
                person.salary += 2000
            print(f"{person.name} - {person.category} ({person.department}) - Salary: Rs {person.salary}")
    '''

'''def avg(lst):
    n = len(lst)
    summ = 0
    for num in lst:
        summ += num
    avg = summ / n
    print(avg)

avg([2, 2, 2, 3, 2])'''

'''class Observer:


    def update(self, job):
        pass

class Printer:

    def __init__(self, category, uid):
        self.obs_list = []
        self.category = category
        self.uid = uid
    
    def __str__(self):
        return f'({self.category}, {self.uid})'
    
    def addObserver(self, obs):
        self.obs_list.append(obs)

    def removeObserver(self):
        self.obs_list.pop(0)

    def printJob(self, obs):
        print("PrintJob", self)
        self.notify()

    def deletePrint(self):
        print("DeletePrint",self)
        self.notify()
    
    def notify(self):
        for x in self.obs_list:
            x.update()

class Employee(Observer):

    def __init__(self):
        pass

    def update(self, job):
        print("", job)

class System(Observer):
    
    def __init__(self):
        pass

    def update(self, job):
        print("", job)

if __name__ == '__main__':
    p = Printer('Employee', 123)
    observer1 = Employee()
    observer2 = System()

    p.addObserver(observer1)
    p.addObserver(observer2)

    p.printJob()
    p.deletePrint()'''

from abc import ABC, abstractmethod

# Product
'''class Readable(ABC):

    @abstractmethod
    def tops(self):
        pass

    @abstractmethod
    def headlines(self):
        pass

    @abstractmethod
    def brief(self):
        pass

    @abstractmethod
    def show_subsidy(self):
        pass

# Concrete Product 1
class Books(Readable):

    def tops(self):
        #print("Top news of Best Selling Books!!")
        pass
    
    def headlines(self):
        #print("Headlines of the chapter: ")
        pass

    def brief(self):
        print("Brief content of Book")

    def show_subsidy(self):
        print("Subscription for Books: Rs. 100")

# Concrete Product 2
class NewsPaper(Readable):

    def tops(self):
        pass

    def headlines(self):
        print("Headlines of the News")

    def brief(self):
        pass

    def show_subsidy(self):
        print("Subscription for Newspaper: Rs. 50")

# Concrete Product 3
class Magazines(Readable):

    def tops(self):
        print("Top Stories of Magazine")

    def headlines(self):
        pass

    def brief(self):
        pass

    def show_subsidy(self):
        print("Subscription for Magazines: Rs. 75")

# Creator
class ReadableFactory:

    @abstractmethod
    def create_readable(self, readable_type):
        pass

    def show_info(self, readable_type):
        readable = self.create_readable(readable_type)
        readable.tops()
        readable.headlines()
        readable.brief()
        readable.show_subsidy()

# Concrete Creator
class HigginsBothams(ReadableFactory):

    def create_readable(self, readable_type):
        if readable_type.lower() == 'books':
            return Books()
        elif readable_type.lower() == 'newspaper':
            return NewsPaper()
        elif readable_type.lower() == 'magazines':
            return Magazines()

# Driver code
if __name__ == '__main__':
    readable_store = HigginsBothams()

    books = readable_store.create_readable("books")
    readable_store.show_info("books")
'''

class IAgeGroup(ABC):
    
    @abstractmethod
    def games(self):
        pass

class Adult(IAgeGroup):

    def games(self):
        print('''List of Games:
                1) Cricket
                2) Football
                3) Basket Ball
                4) Volley Ball''')
    
    def __str__(self):
        print("Adult")

class Seniors(IAgeGroup):

    def games(self):
        print('''List of Games:
                1) Carrom
                2) Chess
                3) Ludo''')
    
    def __str__(self):
        print("Seniors")

class Employee:

    def __init__(self, name, emp_id, emp_type):
        self.name = name
        self.emp_id = emp_id
        self.emp_type = emp_type()
        self.adult_lst = []
        self.seniors_lst = []
        if self.emp_type == "Seniors":
            self.seniors_lst.append((self.name, self.id))
        elif self.emp_type == "Adult":
            self.adult_lst.append((self.name, self.emp_id))
        
    def show(self):
        print(f'''
                Age Group: 
                Name: {self.name}
                Emp ID: {self.emp_id}
                Games: {self.emp_type.games()}''')

if __name__ == '__main__':
    e1 = Employee("sada", 123, Adult)
    e2 = Employee("vada", 456, Seniors)

    e1.show()  
    print()

    e2.show()
    print()